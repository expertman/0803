package kr.co.infopub.chap161.java7;
public class  Bus extends Car{
        private int passenger=3; //
        public void move(){// 3
                System.out.println("Bus  3 passenger :==> "+passenger);
        }
}
