package kr.co.infopub.chap148;
public class FlyerUtil {
	public static void show(Flyer f){
		f.fly();
		System.out.println(f.isAnimal());
	}
}
