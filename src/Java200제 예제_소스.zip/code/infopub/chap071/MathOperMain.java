package kr.co.infopub.chap071;
 public class MathOperMain 
 {
 	public static void main(String[] args) 
 	{
 		System.out.println(MathOper.banOlimAtNums(123.456,3));
 		System.out.println(MathOper.burimAtNums(123.456,3));
 		System.out.println(MathOper.olimAtNums(123.451,3));
 		System.out.println(MathOper.sinh(1));
 		System.out.println(MathOper.cosh(1));
 		System.out.println(MathOper.cosh(1));
 	}
 }
