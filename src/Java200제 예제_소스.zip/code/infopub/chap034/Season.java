package kr.co.infopub.chap034;
//JAVA 5~7
public enum Season  
{
	SPRING,SUMMER,AUTUMN,WINTER
}