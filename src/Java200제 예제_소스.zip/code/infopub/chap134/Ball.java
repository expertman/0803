package kr.co.infopub.chap134;
public class Ball {
	private String name="Ball";//field private
	public void printName(){
		System.out.println("name :"+name);
	}
	public String getName(){//method public 
		return name;
	}
}
