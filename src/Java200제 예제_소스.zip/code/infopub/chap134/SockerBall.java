package kr.co.infopub.chap134;
public class SockerBall extends Ball {
	public void printName(){
		System.out.println("SockerBall");
	}
	public void printSize(){
		System.out.println("SockerBall: "+25.0);
	}
}
