package kr.co.infopub.chap134;
public class BaseBall extends Ball {
	public void printName(){
		System.out.println("BaseBall");
	}
	public void printSize(){
		System.out.println("BaseBall: "+11.0);
	}
}
