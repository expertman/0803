package kr.co.infopub.chap133;
public class BaseBall extends Ball {
	public void printName(){
		System.out.println("BaseBall");
	}
	public void printSize(){
		System.out.println("BaseBall: "+11.0);
	}
}
