package kr.co.infopub.chap133;
public class SockerBall extends Ball {
	public void printName(){
		System.out.println("SockerBall");
	}
	public void printSize(){
		System.out.println("SockerBall: "+25.0);
	}
}
