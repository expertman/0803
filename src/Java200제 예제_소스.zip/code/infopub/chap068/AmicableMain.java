package kr.co.infopub.chap068;

public class AmicableMain {

	public static void main(String[] args) {
		Amicables.printAmicable(2, 10000);
	}

}
