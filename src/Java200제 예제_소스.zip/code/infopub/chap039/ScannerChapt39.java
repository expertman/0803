package kr.co.infopub.chap039;
import java.util.Scanner;
public class ScannerChapt39 {

	public static void main(String[] args) {
		System.out.println("������ �Է��ϼ���.");
		Scanner input=new Scanner(System.in);
		int n=input.nextInt();
		System.out.println(n);
	}
}
