package kr.co.infopub.chap036;
public class DoWhileTest1Chapt36
{
	public static void main(String[] args) 
	{
		int i=15;
		do{
			i++;
			System.out.println("i ��?  "+i);
		}while(i<20);
	}
}
