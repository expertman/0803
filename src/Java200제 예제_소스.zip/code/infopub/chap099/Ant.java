package kr.co.infopub.chap099;
public class Ant {
	private String name="Ant";
	public String getName(){
		return name;
	}
	public String toString(){
		return "�̸�  : "+name;
	}
	public void print(){
		System.out.println(name+"�� ������ ���.");
	}
}
