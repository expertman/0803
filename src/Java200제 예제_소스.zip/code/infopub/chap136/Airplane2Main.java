package kr.co.infopub.chap136;
public class Airplane2Main {

	public static void main(String[] args) {
		Airplane2 air948 =new Airplane2("�̱� ���̺�",6000,11);
		System.out.println(air948.toString());	
		Airplane2 air947 =new Airplane2("��Ÿ ���̺�");
		System.out.println(air947);	
		Airplane2 air949 =new Airplane2();
		System.out.println(air949);	
	}
}
