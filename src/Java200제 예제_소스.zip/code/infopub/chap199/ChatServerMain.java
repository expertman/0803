package kr.co.infopub.chap199;
public class ChatServerMain{
	public static void main(String[] args) {
		ChatServer server=new ChatServer();
		server.giveAndTake();
	}
}
