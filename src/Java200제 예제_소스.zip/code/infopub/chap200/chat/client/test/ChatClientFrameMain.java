package kr.co.infopub.chap200.chat.client.test;

import kr.co.infopub.chap200.chat.client.ChatClientFrame;

public class ChatClientFrameMain {
	public static void main(String[] args) {
		ChatClientFrame sj=new ChatClientFrame();
	}
}
