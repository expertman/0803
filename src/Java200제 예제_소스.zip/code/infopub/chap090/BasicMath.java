package kr.co.infopub.chap090;
public class BasicMath {
	//����
	public static double sum(double a,double b){
		return (a+b);
	}
	public double sums(double a,double b){
		return sum(a,b);
	}
	//����
	public static double sub(double a,double b){
		return (a-b);
	}
	public double subs(double a,double b){
		return sub(a,b);
	}
	//����
	public double multi(double a,double b){
		return (a*b);
	}
}
