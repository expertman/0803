package kr.co.infopub.chap089;
public class BitShiftingMain {

	public static void main(String[] args) {
		BitShifting bit=new BitShifting();
		System.out.println(bit.makeBit(400));
		System.out.println(bit.makeBit(400,2));
		System.out.println(bit.makeBit(400,-2));
	}
}
