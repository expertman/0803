package kr.co.infopub.chap079;
public enum Flower  
{
 	ROSE,LILY,TULIP,AZALEA;
}
