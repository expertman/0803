package kr.co.infopub.chap035;
public class  WhileTest1Chapt35  
{
	public static void main(String[] args) 
	{
		int i=0;
		while( i<10 ){
			System.out.print("["+(i++)+"] ");
		}
		System.out.println();
	}
}
