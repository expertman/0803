package kr.co.infopub.chap086;
public class LeapYearTotalDaysMain
{
	public static void main(String[] args) 
	{
		LeapYearTotalDays leap=new LeapYearTotalDays();
		System.out.println(leap.getTotalDays(2004));
		System.out.println(leap.getTotalDays(2005));
	}
}
