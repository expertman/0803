package kr.co.infopub.chap120;
public class TetrisUtil {
	public static final int [][] TETRISA={
	{1,1,1,0},{0,0,1,0},{0,0,1,0},{0,0,1,0}};
	public static final int [][] TETRISB={
	{0,0,1,0},{0,0,1,0},{0,0,1,0},{0,0,1,0}};
	public static final int [][] TETRISC={
	{0,0,0,0},{1,1,1,0},{0,1,0,0},{0,0,0,0}};
	public static final int [][] TETRISD={
	{0,0,0,0},{0,1,1,0},{0,1,1,0},{0,0,0,0}};
}
