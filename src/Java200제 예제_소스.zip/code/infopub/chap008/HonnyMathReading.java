package kr.co.infopub.chap008;

public class  HonnyMathReading
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
