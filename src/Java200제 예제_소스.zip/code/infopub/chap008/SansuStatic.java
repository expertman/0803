package kr.co.infopub.chap008;
public class SansuStatic {
	public static final int MAN=1;
	public static final int WOMAN=2;
}
