package kr.co.infopub.chap008.test;

import kr.co.infopub.chap008.SansuInterface;
//interface ���
public class SansuInterfaceMain2  {

	public static void main(String[] args) {
		int man=SansuInterface.MAN;
		switch(man){
			case 1: System.out.println("����");break;
			case 2: System.out.println("����");break;
		}
	}
}
