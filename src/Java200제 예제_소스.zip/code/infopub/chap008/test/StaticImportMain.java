package kr.co.infopub.chap008.test;
//static import
import static java.lang.Math.*;
public class StaticImportMain {
	public static void main(String[] args) {
		double r=10.0;
		double c=r*r*PI;    
		double d=sqrt(2.4);
		double e=pow(2,3);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
	}
}
