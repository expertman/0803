package kr.co.infopub.chap008;
public interface SansuInterface {
	public int MAN=1;
	public int WOMAN=2;
}
