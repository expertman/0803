package kr.co.infopub.chap010.java7;

public class SevenNumber {
	public static void main(String[] args) {
		int a=1_000;    //1000
		int b=2_000_000;//2000000
		int c=a+b;
		System.out.println(c);
	}
}
