package kr.co.infopub.chap078;
//JAVA 7 Section 34
public enum Season  
{
	SPRING,SUMMER,AUTUMN,WINTER;
}