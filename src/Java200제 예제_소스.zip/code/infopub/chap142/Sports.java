package kr.co.infopub.chap142;
public class  Sports extends Car
{
        public void show(){// overriding 9
                System.out.println("Sports ~~ 11");
        }
        public int speed(){//overriding 10
                return sped;
        }
        public void works(){//11
                System.out.println("Sports ~works~ 11");
        }
}

