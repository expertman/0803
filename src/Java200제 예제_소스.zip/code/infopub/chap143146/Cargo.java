package kr.co.infopub.chap143146;

public class  Cargo extends Truck
{
        public void passing(){ // 8
                System.out.println("Cargo ~~ 8  ");
        }
}
