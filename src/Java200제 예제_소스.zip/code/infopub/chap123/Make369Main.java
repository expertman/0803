package kr.co.infopub.chap123;
public class Make369Main {

	public static void main(String[] args) {
		Make369 m369=new Make369();
		m369.play369(200);	
	}
}
