package kr.co.infopub.chap125;
public class  GCDUsingRecursiveMain
{
	public static void main(String[] args) 
	{
		GCDUsingRecursive gcre=new GCDUsingRecursive();

		System.out.println(gcre.gcdR(15,80));
		System.out.println(gcre.lcmR(15,80));
	}
}
