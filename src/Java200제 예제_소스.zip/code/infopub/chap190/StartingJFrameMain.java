package kr.co.infopub.chap190;
public class StartingJFrameMain {
  public static void main(String[] args) {
    StartingJFrame startFrame =new StartingJFrame();
  }
}
