package kr.co.infopub.chap149;
public abstract class Plane {
	public abstract void fly();
	public abstract int power();
}
