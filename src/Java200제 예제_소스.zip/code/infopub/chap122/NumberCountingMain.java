package kr.co.infopub.chap122;
public class NumberCountingMain {

	public static void main(String[] args) {
		NumberCounting nc=new NumberCounting();
		System.out.println("123: "+nc.numberSum(123));
		System.out.println("2: "+nc.numberSum(2));
		System.out.println("5354354 : "+nc.numberSum(5354354));
	}
}
